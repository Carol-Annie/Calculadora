import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class button extends StatelessWidget{
  static const  DARK = Color.fromRGBO(82, 82, 82, 1);
  static const  DEFAULT = Color.fromRGBO(247, 255, 248, 1);
  static const  OPERATION = Color.fromRGBO(16, 189, 22, 1);

  final String text;
  final bool grande;
  final Color color;
  final void Function(String) cb;

  button({
  required this.text,
    this.grande = false,
    this.color = DEFAULT,
    required this.cb,
  });

  button.grande({
    required this.text,
    this.grande = false,
    this.color = DEFAULT,
    required this.cb,
  });

  button.operation({
    required this.text,
    this.grande = false,
    this.color = OPERATION,
    required this.cb,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: grande ? 2 : 1,
        child: RaisedButton (
          color: this.color,
          child: Text(
              text,
              style: TextStyle(
                color:  Colors.black45,
                fontSize: 32,
                fontWeight: FontWeight.w200,
              ),
          ),
          onPressed: () => cb(text),
        ),
    );
  }

}