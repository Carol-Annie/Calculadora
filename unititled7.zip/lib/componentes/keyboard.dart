import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'button.dart';
import 'button_row.dart';

class keyboard extends StatelessWidget {

  final void Function(String) cb;

  keyboard(this.cb);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 500,
      child: Column(
        children: <Widget> [
          buttonRow([
            button.grande(text: 'AC',color: button.DARK,cb: cb),
            button.operation(text: '%',cb: cb),
            button.operation(text: '/',cb: cb),
          ]),
          SizedBox(height: 1),
          buttonRow([
            button(text: '7',cb: cb),
            button(text: '8',cb: cb),
            button(text: '9',cb: cb),
            button.operation(text: 'x',cb: cb),
          ]),
          SizedBox(height: 1),
          buttonRow([
            button(text: '4',cb: cb),
            button(text: '5',cb: cb),
            button(text: '6',cb: cb),
            button.operation(text: '-',cb: cb),
          ]),
          SizedBox(height: 1),
          buttonRow([
            button(text: '1',cb: cb),
            button(text: '2',cb: cb),
            button(text: '3',cb: cb),
            button.operation(text: '+',cb: cb),
          ]),
          SizedBox(height: 1),
          buttonRow([
            button.grande(text: '0',cb: cb),
            button(text: '.',cb: cb),
            button(text: '=',cb: cb),
          ]),
        ],
      ) ,
    );
  }
}
