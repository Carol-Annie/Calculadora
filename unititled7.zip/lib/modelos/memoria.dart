import 'package:untitled7/componentes/button.dart';

class memoria {

  static const operations = const['%','/','x','-','+','='];

  final _buffer = [0.0,0.0];
  int _bufferIndex = 0;
  late String _operation;
  String _valor = '0';
  bool _wipevalor = false;
  late String _lastCommand;

  void applyCommand(String command) {

    if(_isReplacingOperation(command)) {
      _operation = command;
      return;
    }

    if(command == 'AC') {
      _allClear();
    } else if (operations.contains(command)) {
      _setOperation(command);
    } else {
      _addDig(command);
    }
    _lastCommand = command;
  }

  _isReplacingOperation(String command) {
    return operations.contains(_lastCommand)
        && operations.contains(command)
        && _lastCommand != '='
        && command != '=';
  }
  _setOperation(String newOperation) {
    bool isEqualSign = newOperation == '=';
    if(_bufferIndex == 0) {
      if(!isEqualSign) {
        _operation = newOperation;
        _bufferIndex = 1;
        _wipevalor = true;
      }
    } else {
      _buffer[0] = _calculate();
      _buffer[1] = 0.0;
      _valor = _buffer[0].toString();
      _valor = _valor.endsWith('.0') ? _valor.split('.')[0] : _valor;
       bool isEqualSign = newOperation == '=';
      _operation = (isEqualSign ? null : newOperation)!;
      _bufferIndex = isEqualSign ? 0 : 1;
    }
    _wipevalor = !isEqualSign;
  }

  _addDig(String dig) {
    final ponto = dig == '.';
    final wipeValor = (_valor == '0' && !ponto) || _wipevalor;

    if(ponto && _valor.contains('.') && !wipeValor) {
      return;
    }

    final emptyValor = ponto ? '0' : '';
    final currentValor = wipeValor ? '' : _valor;
    _valor = currentValor + dig;
    _wipevalor = false;

    _buffer[_bufferIndex] = double.tryParse(_valor) ?? 0;

  }
  _allClear() {
    _valor = '0';
    _buffer.setAll(0, [0.0,0.0]);
    _operation = '';
    _wipevalor = false;
  }

  _calculate() {
    switch(_operation) {
      case '%' : return _buffer[0] % _buffer[1];
      case '/' : return _buffer[0] / _buffer[1];
      case 'x' : return _buffer[0] * _buffer[1];
      case '-' : return _buffer[0] - _buffer[1];
      case '+' : return _buffer[0] + _buffer[1];
      default: return _buffer[0];
    }
  }

  String get Valor {
    return _valor;
  }
}