import 'package:flutter/material.dart';
import 'screen/calcula.dart';

void main() => runApp(calcula());

