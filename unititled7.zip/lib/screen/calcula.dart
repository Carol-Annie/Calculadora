import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled7/componentes/keyboard.dart';
import 'package:untitled7/modelos/memoria.dart';
import '../componentes/display.dart';
import '../componentes/keyboard.dart';

class calcula extends StatefulWidget {
  @override
  _calculaState createState() => _calculaState();
}

class _calculaState extends State<calcula> {
  final memoria Memoria = memoria();

  _onPressed(String command) {
      setState(() {
        Memoria.applyCommand(command);
      });
   }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      home: Column (
        children: <Widget> [
          display(Memoria.Valor),
          keyboard(_onPressed),
        ],
      ),
    );
  }
  }

